# How to Run NSR-Esign — Step by Step

## Part A — One-time setup (build the app, on Windows)

You only need to do this once, or whenever you want to update the app.

1. Install Python 3.10 or newer from https://www.python.org/downloads/
   (skip this step if Python is already installed).
   - On the first install screen, tick **"Add python.exe to PATH"**
     before clicking Install.
2. Put these five files together in one folder:
   - `pdf_signer_app.py`
   - `requirements.txt`
   - `build_portable.bat`
   - `installer.iss`
   - `README.md`
3. Double-click **`build_portable.bat`**.
4. Wait for it to finish (a few minutes the first time). It will:
   - install the required libraries,
   - build the portable app,
   - automatically build a Windows installer too.
5. When it's done, you'll have:
   - `dist\NSR-Esign.exe` — portable, no installation needed
   - `Output\NSR-Esign Setup.exe` — installer, for sharing with others

## Part B — Running the app

1. Double-click **`NSR-Esign.exe`** (or, if you used the installer,
   open **NSR-Esign** from the Start Menu).
   - The first launch may take a few seconds longer than usual — this
     is normal.
   - If Windows shows a blue "Windows protected your PC" notice, click
     **More info → Run anyway**.
2. Click **Open PDF** and select the document you want to sign.
3. Click **Load Signature Image** and select your signature file
   (PNG or JPG).
4. Fill in the **Name** field (your name) and the **Location** field
   (e.g. your city).
5. Click **Insert / Refresh Stamp Text** to auto-fill today's date and
   time. Edit the text box by hand if you want to change anything.
6. *(Optional)* Click **Detect Location & Time (Internet)** for an
   internet-verified place and time, or **Get Exact GPS via Browser**
   for precise coordinates — both require an internet connection and
   can be skipped entirely.
7. Drag the blue box (signature) and the dashed box (text) to where
   you want them on the page. Drag the small square at a box's
   bottom-right corner to resize it.
8. Use **Prev / Next** to check other pages — your placement carries
   over automatically.
9. Under **Pages to stamp**, choose: current page only, all pages, or
   a custom list (e.g. `1,3,5-7`).
10. *(Optional, v2.0)* Tick **"Apply digital signature too"** for a
    free, tamper-evident cryptographic signature on top of the visual
    stamp — see Part C below to set it up first.
11. Click **Export Signed PDF**, choose where to save it, and you're
    done. Your original PDF file is left unchanged.

## Part C — Free digital signature (optional, one-time setup)

This adds a real cryptographic signature (not just a visual stamp) —
free, using a certificate generated on your own computer.

1. Open the **Security** menu → **Set Up Digital Signature (Free)...**
2. Enter your name, organization, and a password to protect it.
3. Click **Create Certificate**.
4. From then on, tick **"Apply digital signature too"** in the side
   panel before exporting — you'll be asked for the password each time.
5. To check any signed PDF later: **Security → Verify PDF
   Signature...**

## Quick reference

| Step | Action |
|---|---|
| 1 | Open PDF |
| 2 | Load Signature Image |
| 3 | Fill Name + Location |
| 4 | Insert / Refresh Stamp Text |
| 5 | Drag & resize the two boxes |
| 6 | Choose pages to stamp |
| 7 | Export Signed PDF |

Everything runs locally on your computer — no PDF or signature image
is ever uploaded. See `README.md` for full details, including the
optional internet-based location/time features.
