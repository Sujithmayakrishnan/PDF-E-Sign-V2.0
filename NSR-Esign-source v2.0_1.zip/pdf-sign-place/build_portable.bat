@echo off
REM ============================================================
REM  NSR-Esign - build script (Windows)
REM
REM  Run this by double-clicking it (or from a Command Prompt)
REM  in the same folder as pdf_signer_app.py. It will:
REM    1. Check that Python is installed
REM    2. Install the required libraries (including the free, optional
REM       cryptographic digital signature feature added in v2.0)
REM    3. Use PyInstaller to build a single portable .exe
REM    4. Detect Inno Setup (a free Windows installer builder) and, if
REM       it isn't already on this computer, download and silently
REM       install it - then use it to build a proper Windows installer
REM       (Start Menu shortcut, optional desktop shortcut, and a
REM       working uninstaller listed in "Add or remove programs")
REM
REM  When it finishes you'll have TWO things:
REM      dist\NSR-Esign.exe            <- portable, no install
REM      Output\NSR-Esign Setup.exe    <- proper installer
REM
REM  Only the portable .exe is required to run the app - the installer
REM  is a nicer way to hand it out to other people (Start Menu entry,
REM  clean uninstall). Step 4 needs an internet connection on THIS
REM  build computer only; end users never need internet to install or
REM  run either version. If step 4 can't complete for any reason (no
REM  internet here, a locked-down network, etc.) the script still
REM  finishes successfully with the portable .exe from step 3 alone.
REM ============================================================

setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo Checking for Python...
set "PYCHECK="
for /f "delims=" %%v in ('python --version 2^>^&1') do if not defined PYCHECK set "PYCHECK=%%v"
echo %PYCHECK% | findstr /r /b /i "Python [0-9]" >nul
if errorlevel 1 (
    echo.
    echo ERROR: A working Python installation was not found on this computer.
    echo.
    echo If Windows just showed a message above about installing Python from
    echo the Microsoft Store, please IGNORE that Store shortcut - it is not a
    echo real Python install and this script cannot use it.
    echo.
    echo Please install Python 3.10 or newer from:
    echo     https://www.python.org/downloads/
    echo IMPORTANT: on the first install screen, tick "Add python.exe to PATH".
    echo.
    echo If Python is already installed on this computer and you still see
    echo this message, the Microsoft Store shortcut is intercepting the
    echo "python" command. Turn it off from:
    echo     Settings ^> Apps ^> Advanced app settings ^> App execution aliases
    echo then switch OFF "python.exe" and "python3.exe".
    echo.
    echo Then close this window and run build_portable.bat again.
    pause
    exit /b 1
)

echo Found: %PYCHECK%

echo.
echo Installing required libraries (PyMuPDF, Pillow, PyInstaller, and the
echo cryptography/pyHanko libraries used by the free digital signature
echo feature)...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo ERROR: Failed to install required libraries. See the messages above.
    pause
    exit /b 1
)

echo.
echo Building the portable .exe with PyInstaller...
REM The --collect-all flags below make sure PyInstaller bundles everything
REM the free digital signature feature (pyHanko + cryptography) needs at
REM runtime - these libraries load some of their pieces dynamically, which
REM PyInstaller's automatic detection can otherwise miss.
python -m PyInstaller --noconfirm --onefile --windowed ^
    --name "NSR-Esign" ^
    --collect-all pyhanko ^
    --collect-all pyhanko_certvalidator ^
    --collect-all asn1crypto ^
    --collect-all oscrypto ^
    --collect-all certifi ^
    --collect-all cryptography ^
    pdf_signer_app.py

if errorlevel 1 (
    echo.
    echo ERROR: PyInstaller build failed. See the messages above.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  Portable .exe build complete:
echo    dist\NSR-Esign.exe
echo ============================================================

REM ------------------------------------------------------------
REM  Step 4: find (or fetch) Inno Setup, then build the installer.
REM  This step is best-effort - if anything here fails, the portable
REM  .exe above is already a complete, working result on its own.
REM ------------------------------------------------------------

set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles(x86)%\Inno Setup 5\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 5\ISCC.exe"

if defined ISCC (
    echo.
    echo Found Inno Setup already installed - skipping download.
    goto :build_installer
)

echo.
echo Inno Setup (the free tool used to build a proper Windows installer)
echo was not found on this computer. Attempting to download and install
echo it automatically now - this needs an internet connection on THIS
echo build computer only and may take a minute.
echo.

set "INNO_SETUP_TMP=%TEMP%\innosetup-install.exe"
set "DOWNLOAD_OK=0"

where curl >nul 2>nul
if not errorlevel 1 (
    curl -L --fail -o "%INNO_SETUP_TMP%" "https://www.jrsoftware.org/download.php/is.exe?site=1"
    if not errorlevel 1 if exist "%INNO_SETUP_TMP%" set "DOWNLOAD_OK=1"
)

if "%DOWNLOAD_OK%"=="0" (
    echo curl download did not work - trying PowerShell instead...
    powershell -NoProfile -Command "try { Invoke-WebRequest -Uri 'https://www.jrsoftware.org/download.php/is.exe?site=1' -OutFile '%INNO_SETUP_TMP%' -UseBasicParsing } catch { exit 1 }"
    if not errorlevel 1 if exist "%INNO_SETUP_TMP%" set "DOWNLOAD_OK=1"
)

if "%DOWNLOAD_OK%"=="0" (
    echo.
    echo Could not download Inno Setup automatically - this usually means
    echo there is no internet connection on this computer right now, or a
    echo firewall is blocking it. This is fine: your portable .exe from
    echo step 3 above is complete and ready to use on its own.
    echo.
    echo To build a Windows installer later, download Inno Setup yourself
    echo from https://jrsoftware.org/isdl.php , install it, then run this
    echo script again ^(or open installer.iss in the Inno Setup Compiler
    echo and click Build ^> Compile^).
    goto :done
)

echo Installing Inno Setup silently - if Windows asks whether to allow
echo this app to make changes to your device, click Yes to continue...
"%INNO_SETUP_TMP%" /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-
del "%INNO_SETUP_TMP%" >nul 2>nul

if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"

if not defined ISCC (
    echo.
    echo Inno Setup's installer ran but ISCC.exe still could not be found
    echo ^(it may need administrator rights to install, or the install was
    echo cancelled^). Your portable .exe from step 3 above is still
    echo complete and ready to use - the installer step was simply
    echo skipped. You can install Inno Setup yourself from
    echo https://jrsoftware.org/isdl.php and run this script again.
    goto :done
)

echo Inno Setup installed successfully.

:build_installer
echo.
echo Building the Windows installer with Inno Setup...
"%ISCC%" installer.iss
if errorlevel 1 (
    echo.
    echo ERROR: Inno Setup failed to build the installer. See the messages
    echo above. Your portable .exe from step 3 above is still complete and
    echo ready to use on its own.
    goto :done
)

echo.
echo ============================================================
echo  Installer build complete:
echo    Output\NSR-Esign Setup.exe
echo  Hand that one file to anyone - it installs the app with a
echo  Start Menu shortcut and a clean uninstaller, no admin rights
echo  or Python needed on their computer.
echo ============================================================

:done
echo.
echo ============================================================
echo  ALL DONE
echo    Portable, no install:  dist\NSR-Esign.exe
if defined ISCC if exist "Output\NSR-Esign Setup.exe" echo    Windows installer:      Output\NSR-Esign Setup.exe
echo ============================================================
echo.
pause
