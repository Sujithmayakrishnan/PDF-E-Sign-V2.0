#!/usr/bin/env python3
"""
NSR-Esign
=========

A small portable desktop app for stamping a signature image plus a
"Place / Date / Time" text block onto a PDF - similar to a simple
e-signature tool. All PDF/image work happens 100% locally on this
computer (no upload, no account). Two location buttons are optional
exceptions, only active when clicked and only if this computer
currently has internet access:
  - "Detect Location & Time (Internet)" looks up an approximate
    location and an authoritative UTC time (independent of this
    computer's own clock) from the device's public IP address.
  - "Get Exact GPS via Browser" briefly opens the user's web browser,
    which asks the operating system for the device's exact GPS
    coordinates (far more accurate than an IP-based guess) and reports
    the result straight back to this app.
If there is no internet connection, or a lookup fails for any reason,
the app falls back automatically to manual location entry and this
computer's system clock, exactly as before. Built with Tkinter (GUI)
and PyMuPDF (PDF rendering/editing).

New in v2.0: an optional, FREE cryptographic digital signature
(Security menu). This uses a self-signed certificate generated on
this computer, at no cost - unlike the visual signature image/stamp
above, it is genuine public-key cryptography: it proves who signed a
document and makes any change made after signing detectable. It is
applied on top of, not instead of, the visual stamp, and is entirely
optional - v1.0's visual-only stamping still works exactly as before
if this is left off. Uses the "pyHanko" and "cryptography" libraries.

Workflow:
  1. Open a PDF.
  2. Load a signature image (PNG with a transparent background works best).
  3. Optionally click "Detect Location & Time (Internet)" for an
     approximate place name + verified time, and/or "Get Exact GPS via
     Browser" for precise coordinates - or just type a location by
     hand and use this computer's clock.
  4. Drag / resize the signature box and the Place-Date-Time text box
     on the page preview until they sit where you want them.
  5. Choose which page(s) to stamp (current page / all pages / a
     custom list such as "1,3,5-7").
  6. Click "Export Signed PDF" to save a new PDF with the signature
     and text burned in. The original file is never modified.

This file is self-contained and is meant to be frozen into a single
portable .exe with PyInstaller (see build_portable.bat).

Author: built for Sujith (IQAC, Sanjivani University)
"""

import os
import re
import sys
import json
import socket
import datetime
import threading
import webbrowser
import http.server
import urllib.error
import urllib.parse
import urllib.request
from email.utils import parsedate_to_datetime

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

try:
    import pymupdf as fitz  # PyMuPDF (new import name, 1.24+)
except ImportError:
    try:
        import fitz  # PyMuPDF (legacy import name)
    except ImportError:
        fitz = None

try:
    from PIL import Image, ImageTk
except ImportError:
    Image = None
    ImageTk = None


APP_TITLE = "NSR-Esign"
APP_VERSION = "2.0.0"
LICENSE_TEXT = "licensed to Sujith Mayakrishnan (IQAC, Sanjivani University)"

MIN_BOX_PT = 12.0          # smallest a box may be shrunk to, in PDF points
HANDLE_PX = 10              # size of the resize-handle square, in canvas pixels
DEFAULT_ZOOM = 1.3          # initial render zoom (points -> pixels)
MAX_CANVAS_DIM = 1400        # safety cap so huge pages don't blow up memory


# --------------------------------------------------------------------------
# Small standalone helpers (kept free of any Tkinter/GUI dependency so they
# can be unit-tested and reused on their own).
# --------------------------------------------------------------------------

def app_base_dir():
    """Directory the app (or the frozen .exe) lives in - used to keep the
    settings file next to the executable so the app stays 'portable' (no
    writes to the user's home directory or the registry)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def config_path():
    return os.path.join(app_base_dir(), "pdf_sign_place_settings.json")


def load_config():
    path = config_path()
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except (OSError, json.JSONDecodeError):
            pass
    return {}


def save_config(cfg):
    try:
        with open(config_path(), "w", encoding="utf-8") as fh:
            json.dump(cfg, fh, indent=2)
    except OSError:
        pass


def format_stamp_text(
    location, dt, lat=None, lon=None, include_coords=False, verified=False,
    precise=False, accuracy_m=None, name=None,
):
    """Build the Name/Place/Date/Time stamp text. `dt` is a naive or aware
    datetime already in the wall-clock value that should be displayed
    (callers convert internet UTC time to local time before passing it
    in). When `verified` is True, a short note marks the time as
    internet-verified rather than taken from this computer's clock.
    `precise` marks coordinates captured via the browser's exact GPS
    (as opposed to an approximate IP-based estimate); `accuracy_m`, when
    given, is the browser-reported accuracy radius in metres. `name`, when
    given, is the signer's name and is stamped as the first line - the
    common "Name / Place / Date" signature-block order."""
    nm = name.strip() if name else ""
    loc = location.strip() if location else ""
    lines = []
    if nm:
        lines.append(f"Name: {nm}")
    if loc:
        lines.append(f"Place: {loc}")
    if include_coords and lat is not None and lon is not None:
        coord_line = f"Lat/Long: {lat:.5f}, {lon:.5f}"
        if precise:
            coord_line += f" (GPS, ±{accuracy_m:.0f} m)" if accuracy_m is not None else " (GPS)"
        else:
            coord_line += " (approx.)"
        lines.append(coord_line)
    lines.append(f"Date: {dt.strftime('%d-%m-%Y')}")
    time_line = f"Time: {dt.strftime('%I:%M %p')}"
    if verified:
        time_line += " (internet-verified)"
    lines.append(time_line)
    return "\n".join(lines)


def default_stamp_text(location):
    """Simple fallback used before any document is open / before the
    interactive text box has been populated - always uses this
    computer's own clock."""
    return format_stamp_text(location, datetime.datetime.now())


# --- Internet-based location & time lookup (optional, opt-in) -----------
#
# Uses only the Python standard library (urllib) so no extra dependency
# has to be bundled into the portable .exe. Each provider is a plain
# HTTPS JSON endpoint that looks up the caller's approximate location
# from their public IP address - no API key, no account. The HTTP
# response's own "Date" header (sent by every compliant web server) is
# reused as an authoritative UTC time, independent of this computer's
# own clock.

GEO_LOOKUP_USER_AGENT = "PDF-Sign-and-Place/1.0 (offline PDF signing tool)"


def _parse_ipapi_co(data):
    if data.get("error"):
        raise ValueError(data.get("reason") or "ipapi.co reported an error")
    lat, lon = data.get("latitude"), data.get("longitude")
    parts = [p for p in (data.get("city"), data.get("region"), data.get("country_name")) if p]
    return ", ".join(parts), lat, lon


def _parse_ipwho_is(data):
    if data.get("success") is False:
        raise ValueError(data.get("message") or "ipwho.is reported an error")
    lat, lon = data.get("latitude"), data.get("longitude")
    parts = [p for p in (data.get("city"), data.get("region"), data.get("country")) if p]
    return ", ".join(parts), lat, lon


GEO_ENDPOINTS = (
    ("https://ipapi.co/json/", _parse_ipapi_co),
    ("https://ipwho.is/", _parse_ipwho_is),
)

# Used only as a last resort to timestamp the result if neither geolocation
# endpoint's own response header was usable.
TIME_ONLY_HOSTS = ("https://www.cloudflare.com", "https://www.google.com")


def _http_get_json(url, timeout):
    req = urllib.request.Request(url, headers={"User-Agent": GEO_LOOKUP_USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        date_header = resp.headers.get("Date")
        raw = resp.read().decode("utf-8", errors="replace")
    dt = None
    if date_header:
        try:
            dt = parsedate_to_datetime(date_header)
        except (TypeError, ValueError):
            dt = None
    return json.loads(raw), dt


def _fetch_time_only(timeout):
    for url in TIME_ONLY_HOSTS:
        try:
            req = urllib.request.Request(
                url, method="HEAD", headers={"User-Agent": GEO_LOOKUP_USER_AGENT}
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                date_header = resp.headers.get("Date")
            if date_header:
                return parsedate_to_datetime(date_header)
        except Exception:
            continue
    return None


def fetch_internet_location_and_time(timeout=6):
    """Look up an approximate place name, latitude/longitude, and the
    current UTC time via the internet, using the caller's public IP
    address. Tries each provider in GEO_ENDPOINTS in turn.

    Returns (place_text, lat, lon, utc_datetime).
    Raises RuntimeError (with a human-readable message) if every
    provider fails - most commonly because there is no internet
    connection right now.
    """
    last_err = None
    for url, parser in GEO_ENDPOINTS:
        try:
            data, dt = _http_get_json(url, timeout)
            place, lat, lon = parser(data)
            if dt is None:
                dt = _fetch_time_only(timeout) or datetime.datetime.now(datetime.timezone.utc)
            return place, lat, lon, dt
        except (urllib.error.URLError, socket.timeout, ValueError, TimeoutError, OSError) as exc:
            last_err = exc
            continue
    raise RuntimeError(
        "Could not reach an internet location service - this usually means "
        f"there is no internet connection right now. ({last_err})"
    )


# --- Exact GPS coordinates via the browser's Geolocation API ------------
#
# IP-based lookups (above) are only ever approximate - often city-level,
# sometimes off by many kilometres. A web browser's built-in Geolocation
# API (navigator.geolocation) can use the device's real GPS chip / Wi-Fi
# positioning for much tighter accuracy, but that API only exists inside
# a browser page, not in a desktop app. So when the user clicks "Get
# Exact GPS via Browser", this app briefly runs a tiny local web server
# on 127.0.0.1 (not reachable from outside this computer), opens that
# page in the user's normal browser, the page asks the browser for the
# device's location, and reports the result straight back to this app.
# Browsers treat http://127.0.0.1 as a "secure context", so this works
# without needing HTTPS/certificates.

GEO_CAPTURE_PAGE_HTML = """<!doctype html>
<html><head><meta charset="utf-8"><title>NSR-Esign - location</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body { font-family: -apple-system, Segoe UI, Helvetica, Arial, sans-serif;
         max-width: 480px; margin: 15vh auto 0; padding: 0 24px; color: #222; text-align: center; }
  h1 { font-size: 1.15rem; margin-bottom: 0.5rem; }
  #msg { font-size: 1rem; }
  .ok  { color: #1a7f37; }
  .err { color: #c0392b; }
</style></head>
<body>
<h1>NSR-Esign</h1>
<p id="msg">Requesting your precise location from this browser&hellip;</p>
<script>
function report(path, payload) {
  fetch(path, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(payload)
  }).catch(function () {});
}
var msgEl = document.getElementById("msg");
if (!navigator.geolocation) {
  msgEl.textContent = "This browser does not support location services.";
  msgEl.className = "err";
  report("/error", {message: "Geolocation API not supported by this browser."});
} else {
  navigator.geolocation.getCurrentPosition(
    function (pos) {
      report("/coords", {
        latitude: pos.coords.latitude,
        longitude: pos.coords.longitude,
        accuracy: pos.coords.accuracy
      });
      msgEl.textContent = "Location captured \\u2014 you can close this tab and return to NSR-Esign.";
      msgEl.className = "ok";
    },
    function (err) {
      var reason = err && err.message ? err.message : "permission denied";
      report("/error", {message: reason});
      msgEl.textContent = "Could not get your location (" + reason + "). You can close this tab.";
      msgEl.className = "err";
    },
    {enableHighAccuracy: true, timeout: 15000, maximumAge: 0}
  );
}
</script>
</body></html>"""


class _GeoCaptureResult:
    """Shared mailbox between the local web server's request handler
    (running on a background thread) and the code waiting for it."""

    def __init__(self):
        self.event = threading.Event()
        self.lat = None
        self.lon = None
        self.accuracy = None
        self.error = None


def _make_geo_capture_handler(result, page_bytes):
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            pass  # keep this silent - there is no console in the windowed .exe

        def _send_json(self, status, obj):
            body = json.dumps(obj).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(page_bytes)))
                self.end_headers()
                self.wfile.write(page_bytes)
            else:
                self.send_response(404)
                self.end_headers()

        def do_POST(self):
            length = int(self.headers.get("Content-Length", "0") or "0")
            raw = self.rfile.read(length) if length else b"{}"
            try:
                data = json.loads(raw.decode("utf-8", errors="replace"))
            except json.JSONDecodeError:
                data = {}
            if self.path == "/coords":
                result.lat = data.get("latitude")
                result.lon = data.get("longitude")
                result.accuracy = data.get("accuracy")
                result.event.set()
            elif self.path == "/error":
                result.error = data.get("message") or "Location request failed or was denied."
                result.event.set()
            self._send_json(200, {"ok": True})

    return Handler


def start_geo_capture_server():
    """Starts the local 127.0.0.1 server on an OS-assigned free port and
    returns (server, result). Caller is responsible for running
    server.serve_forever() on a background thread and eventually calling
    server.shutdown() from a *different* thread."""
    result = _GeoCaptureResult()
    handler_cls = _make_geo_capture_handler(result, GEO_CAPTURE_PAGE_HTML.encode("utf-8"))
    server = http.server.HTTPServer(("127.0.0.1", 0), handler_cls)
    return server, result


NOMINATIM_REVERSE_URL = "https://nominatim.openstreetmap.org/reverse"


def reverse_geocode(lat, lon, timeout=6):
    """Turn exact coordinates into a human-readable place name using
    OpenStreetMap's free Nominatim service. Returns None (never raises)
    if the lookup fails - the coordinates themselves are still usable
    without a place name."""
    try:
        params = urllib.parse.urlencode({
            "format": "jsonv2", "lat": f"{lat:.6f}", "lon": f"{lon:.6f}",
            "zoom": 14, "addressdetails": 1,
        })
        req = urllib.request.Request(
            f"{NOMINATIM_REVERSE_URL}?{params}",
            headers={"User-Agent": GEO_LOOKUP_USER_AGENT},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
        addr = data.get("address", {})
        city = next(
            (addr[k] for k in ("city", "town", "village", "suburb", "county") if addr.get(k)),
            None,
        )
        region = addr.get("state") or addr.get("state_district")
        country = addr.get("country")
        place = ", ".join(p for p in (city, region, country) if p)
        return place or data.get("display_name")
    except Exception:
        return None


def parse_page_list(spec, page_count):
    """Parse a 1-based page spec like '1,3,5-7' into a sorted list of
    0-based page indices, clamped to the document's page range.
    Raises ValueError with a human-readable message on bad input."""
    spec = (spec or "").strip()
    if not spec:
        raise ValueError("Enter at least one page number (e.g. 1 or 1,3,5-7).")
    indices = set()
    for chunk in spec.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        m = re.match(r"^(\d+)\s*-\s*(\d+)$", chunk)
        if m:
            start, end = int(m.group(1)), int(m.group(2))
            if start > end:
                start, end = end, start
            for p in range(start, end + 1):
                indices.add(p - 1)
        elif chunk.isdigit():
            indices.add(int(chunk) - 1)
        else:
            raise ValueError(f"Could not understand '{chunk}' as a page number.")
    valid = sorted(i for i in indices if 0 <= i < page_count)
    if not valid:
        raise ValueError("None of the pages given exist in this document.")
    return valid


def clamp_rect_to_page(rect_pts, page_w, page_h, min_size=MIN_BOX_PT):
    """rect_pts = (x0, y0, x1, y1) in PDF points. Returns a rect fully
    inside the page, at least min_size wide/tall."""
    x0, y0, x1, y1 = rect_pts
    w = max(x1 - x0, min_size)
    h = max(y1 - y0, min_size)
    x0 = min(max(x0, 0), max(page_w - w, 0))
    y0 = min(max(y0, 0), max(page_h - h, 0))
    return (x0, y0, x0 + w, y0 + h)


def scale_rect_between_pages(rect_pts, src_w, src_h, dst_w, dst_h):
    """Proportionally re-map a box from one page size to another (used
    when the same placement is applied across pages of differing size)."""
    if src_w <= 0 or src_h <= 0:
        return rect_pts
    x0, y0, x1, y1 = rect_pts
    sx = dst_w / src_w
    sy = dst_h / src_h
    return (x0 * sx, y0 * sy, x1 * sx, y1 * sy)


# --------------------------------------------------------------------------
# Core PDF operation - deliberately kept independent of the GUI so it can
# be unit tested by calling it directly on a sample PDF/image.
# --------------------------------------------------------------------------

MIN_TEXT_FONT_SIZE = 6  # never auto-shrink smaller than this, in points


def _find_arial_fonts():
    """Look for the real Arial TrueType files on this Windows machine, so
    the exported stamp text embeds genuine Arial rather than PyMuPDF's
    built-in Helvetica substitute. Windows ships Arial with every install,
    so this normally succeeds; on any machine where it doesn't (e.g. this
    app running somewhere other than Windows during development), callers
    fall back to Helvetica, which every PDF viewer already renders as a
    metrics-compatible stand-in for Arial. Returns (regular_path, bold_path)
    - either may be None."""
    roots = [os.environ.get("WINDIR"), os.environ.get("SystemRoot"), r"C:\Windows"]
    regular = bold = None
    for root in roots:
        if not root:
            continue
        candidate_reg = os.path.join(root, "Fonts", "arial.ttf")
        candidate_bold = os.path.join(root, "Fonts", "arialbd.ttf")
        if regular is None and os.path.exists(candidate_reg):
            regular = candidate_reg
        if bold is None and os.path.exists(candidate_bold):
            bold = candidate_bold
    return regular, bold


ARIAL_REGULAR_PATH, ARIAL_BOLD_PATH = _find_arial_fonts()


def resolve_stamp_font(bold):
    """Returns (fontname, fontfile) for the stamp text: real embedded
    Arial when found on this machine, otherwise PyMuPDF's built-in
    Helvetica (fontfile=None), which reads as Arial in virtually every
    PDF viewer even when Arial itself isn't available to embed."""
    if bold and ARIAL_BOLD_PATH:
        return "Arial-Bold", ARIAL_BOLD_PATH
    if not bold and ARIAL_REGULAR_PATH:
        return "Arial", ARIAL_REGULAR_PATH
    return ("hebo" if bold else "helv"), None


def _textbox_fits(rect_pts, text, fontsize, fontname, fontfile, page_w, page_h):
    """Test-fit `text` into `rect_pts` at `fontsize` by drawing it on a
    disposable scratch page of the same dimensions (never touches the
    real document). PyMuPDF's insert_textbox() silently drops whatever
    doesn't fit - it does not raise or wrap outside the box - so this is
    the only reliable way to find out beforehand."""
    scratch = fitz.open()
    try:
        page = scratch.new_page(width=page_w, height=page_h)
        kwargs = {"fontsize": fontsize, "fontname": fontname, "align": fitz.TEXT_ALIGN_LEFT}
        if fontfile:
            kwargs["fontfile"] = fontfile
        rc = page.insert_textbox(fitz.Rect(*rect_pts), text, **kwargs)
        return rc >= 0
    finally:
        scratch.close()


def _best_fitting_fontsize(rect_pts, text, fontname, fontfile, page_w, page_h, start_size):
    """Returns the largest font size <= start_size that fits the given
    text into rect_pts without PyMuPDF silently dropping any of it,
    shrinking down to MIN_TEXT_FONT_SIZE as a last resort. Returns
    (fontsize, fits) - fits is False only if even the smallest size
    still overflows (e.g. the box is too small for even one line)."""
    size = max(int(start_size), MIN_TEXT_FONT_SIZE)
    while size > MIN_TEXT_FONT_SIZE:
        if _textbox_fits(rect_pts, text, size, fontname, fontfile, page_w, page_h):
            return size, True
        size -= 1
    fits = _textbox_fits(rect_pts, text, MIN_TEXT_FONT_SIZE, fontname, fontfile, page_w, page_h)
    return MIN_TEXT_FONT_SIZE, fits


def apply_stamp_to_pdf(
    src_path,
    out_path,
    signature_image_path,
    sig_rect_by_page,
    text_rect_by_page,
    text_content,
    font_size=11,
    bold=False,
    text_color=(0, 0, 0),
    include_signature=True,
    include_text=True,
):
    """Burn the signature image and/or text block into the given pages of
    a PDF and save the result to out_path. The source file is opened fresh
    and is never modified in place.

    sig_rect_by_page / text_rect_by_page: dict {page_index: (x0,y0,x1,y1)}
    giving the placement rectangle (in that page's own point space) for
    each page index that should be stamped.

    Returns a dict {page_index: used_fontsize} for every page the text was
    written to. IMPORTANT: PyMuPDF's insert_textbox() silently discards any
    text that doesn't fit the given rectangle - it does not raise, wrap
    outside the box, or shrink on its own, and an overflow can drop the
    *entire* text block, not just the last line. To make sure the
    Place/Date/Time stamp is never silently lost, this function always
    test-fits the text first and automatically shrinks the font (down to
    MIN_TEXT_FONT_SIZE) just enough to make everything fit before drawing.
    If a page's returned fontsize is below the requested one, the text was
    shrunk to fit; if a page is missing from the dict entirely, not even
    the smallest size fit and the box should be made bigger.
    """
    if fitz is None:
        raise RuntimeError("PyMuPDF (fitz) is not installed.")

    doc = fitz.open(src_path)
    used_fontsizes = {}
    try:
        # Real Arial when this machine has it (normal on Windows), else the
        # built-in Helvetica, which every PDF viewer renders as Arial anyway.
        fontname, fontfile = resolve_stamp_font(bold)
        for page_index, rect_pts in (sig_rect_by_page or {}).items():
            if not include_signature:
                break
            if page_index < 0 or page_index >= doc.page_count:
                continue
            page = doc[page_index]
            rect = fitz.Rect(*rect_pts)
            page.insert_image(rect, filename=signature_image_path, keep_proportion=True)

        for page_index, rect_pts in (text_rect_by_page or {}).items():
            if not include_text:
                break
            if page_index < 0 or page_index >= doc.page_count:
                continue
            page = doc[page_index]
            pw, ph = page.rect.width, page.rect.height
            actual_size, fits = _best_fitting_fontsize(
                rect_pts, text_content, fontname, fontfile, pw, ph, font_size
            )
            insert_kwargs = {
                "fontsize": actual_size, "fontname": fontname,
                "color": text_color, "align": fitz.TEXT_ALIGN_LEFT,
            }
            if fontfile:
                insert_kwargs["fontfile"] = fontfile
            page.insert_textbox(fitz.Rect(*rect_pts), text_content, **insert_kwargs)
            if fits:
                used_fontsizes[page_index] = actual_size

        doc.save(out_path, garbage=4, deflate=True)
    finally:
        doc.close()
    return used_fontsizes


def render_page_to_photo_data(pdf_path, page_index, zoom):
    """Utility used outside Tk (e.g. for tests) to confirm a page renders.
    Returns (width_px, height_px, png_bytes)."""
    doc = fitz.open(pdf_path)
    try:
        page = doc[page_index]
        mat = fitz.Matrix(zoom, zoom)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        return pix.width, pix.height, pix.tobytes("png")
    finally:
        doc.close()


# --------------------------------------------------------------------------
# Free cryptographic digital signature (v2.0, optional)
# --------------------------------------------------------------------------
# This adds a REAL, tamper-evident PAdES digital signature on top of the
# visual stamp above - the kind PDF viewers (Adobe Reader, etc.) recognise
# and can validate, as opposed to the visual signature image/text which is
# just pixels on the page. It uses a SELF-SIGNED certificate generated for
# free, right here on this computer - no paid Certificate Authority (CA)
# needed. The trade-off of a free, self-signed certificate: PDF viewers
# will show the signature as cryptographically INTACT (proves the document
# was not altered after signing, and who signed it) but not automatically
# "trusted" the way a paid CA-issued certificate would be, unless the
# institution's own certificate is added to each recipient's trusted list.
# This is still a meaningful, genuine upgrade over the visual-only stamp:
# it is real public-key cryptography, and any edit made after signing is
# detectable.
#
# Everything here happens 100% locally - the certificate and private key
# never leave this computer, and signing/verifying needs no internet
# connection.

try:
    from cryptography import x509 as _x509
    from cryptography.hazmat.primitives import hashes as _hashes
    from cryptography.hazmat.primitives import serialization as _serialization
    from cryptography.hazmat.primitives.asymmetric import rsa as _rsa
    from cryptography.hazmat.primitives.serialization import pkcs12 as _pkcs12
    from cryptography.x509.oid import NameOID as _NameOID

    from pyhanko.sign import signers as _signers
    from pyhanko.sign.fields import SigSeedSubFilter as _SigSeedSubFilter
    from pyhanko.sign.signers.pdf_signer import PdfSignatureMetadata as _PdfSignatureMetadata
    from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter as _IncrementalPdfFileWriter
    from pyhanko.pdf_utils.reader import PdfFileReader as _PdfFileReader

    SIGNING_AVAILABLE = True
    _SIGNING_IMPORT_ERROR = None
except Exception as _exc:  # pragma: no cover - only hit if the libraries are missing
    SIGNING_AVAILABLE = False
    _SIGNING_IMPORT_ERROR = _exc


CERT_FILE_NAME = "nsr_esign_certificate.pfx"
SIGNATURE_FIELD_NAME = "NSREsignSignature"


def certificate_path():
    """Where this computer's free self-signed certificate lives - next to
    the app, like the settings file, so the whole install stays portable."""
    return os.path.join(app_base_dir(), CERT_FILE_NAME)


def generate_self_signed_certificate(common_name, organization, password, out_path=None, valid_days=3650):
    """Create a free, self-signed RSA/X.509 certificate + private key for
    digitally signing PDFs, and save it as a password-protected PKCS#12
    (.pfx) file. Returns the path written to.

    This is NOT a CA-issued certificate - PDF viewers will not show it as
    automatically "trusted" - but it is genuine public-key cryptography:
    it proves who signed a document and detects any change made to it
    afterwards, which a plain visual stamp cannot do.
    """
    if not SIGNING_AVAILABLE:
        raise RuntimeError(
            "Digital signature support is not available in this build "
            f"(missing library: {_SIGNING_IMPORT_ERROR})."
        )
    if not common_name.strip():
        raise ValueError("Name is required to create a digital signature certificate.")
    if not password:
        raise ValueError("A password is required to protect the certificate.")

    out_path = out_path or certificate_path()

    key = _rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = issuer = _x509.Name([
        _x509.NameAttribute(_NameOID.COMMON_NAME, common_name.strip()),
        _x509.NameAttribute(_NameOID.ORGANIZATION_NAME, (organization or "").strip() or common_name.strip()),
    ])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (
        _x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(_x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=valid_days))
        .add_extension(_x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            _x509.KeyUsage(
                digital_signature=True, content_commitment=True, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=False,
                crl_sign=False, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .sign(key, _hashes.SHA256())
    )

    pfx_bytes = _pkcs12.serialize_key_and_certificates(
        name=b"NSR-Esign",
        key=key,
        cert=cert,
        cas=None,
        encryption_algorithm=_serialization.BestAvailableEncryption(password.encode("utf-8")),
    )
    with open(out_path, "wb") as fh:
        fh.write(pfx_bytes)
    return out_path


def sign_pdf_cryptographically(input_path, output_path, pfx_path, password, signer_name=None, reason=None, location=None):
    """Add a real PAdES cryptographic signature to an already-exported PDF
    (the one with the visual signature/stamp already burned in). Raises on
    failure (wrong password, missing/corrupt certificate, etc.)."""
    if not SIGNING_AVAILABLE:
        raise RuntimeError(
            "Digital signature support is not available in this build "
            f"(missing library: {_SIGNING_IMPORT_ERROR})."
        )
    if not os.path.exists(pfx_path):
        raise RuntimeError("No digital signature certificate was found. Set one up first.")

    signer = _signers.SimpleSigner.load_pkcs12(pfx_file=pfx_path, passphrase=password.encode("utf-8"))
    if signer is None:
        raise RuntimeError("Could not open the certificate - the password may be incorrect.")

    with open(input_path, "rb") as inf:
        writer = _IncrementalPdfFileWriter(inf)
        meta = _PdfSignatureMetadata(
            field_name=SIGNATURE_FIELD_NAME,
            reason=reason or "Signed with NSR-Esign",
            location=location or "",
            name=signer_name or "",
            subfilter=_SigSeedSubFilter.PADES,
        )
        with open(output_path, "wb") as outf:
            _signers.sign_pdf(writer, meta, signer=signer, output=outf)


def verify_pdf_signatures(path):
    """Check a PDF for embedded NSR-Esign (or other PAdES/PKCS#7) digital
    signatures. Returns a list of dicts, one per signature found:
        {
            "field_name": str,
            "signer_cn": str,
            "organization": str,
            "signed_at": datetime or None,
            "intact": bool,   # document unchanged since this signature was applied
            "detail": str,    # short human-readable explanation
        }
    Returns an empty list if the PDF has no digital signatures at all (this
    is normal for a PDF that was only visually stamped, not cryptographically
    signed). Raises only if the file cannot be read as a PDF at all.
    """
    if not SIGNING_AVAILABLE:
        raise RuntimeError(
            "Digital signature support is not available in this build "
            f"(missing library: {_SIGNING_IMPORT_ERROR})."
        )

    results = []
    with open(path, "rb") as fh:
        reader = _PdfFileReader(fh)
        embedded = reader.embedded_signatures
        for sig in embedded:
            native = sig.signer_cert.subject.native
            signer_cn = native.get("common_name", "(unknown)")
            organization = native.get("organization_name", "")
            signed_at = sig.self_reported_timestamp

            intact = False
            detail = "Could not determine signature status."
            try:
                sig.compute_integrity_info()
                summary = sig.summarise_integrity_info()
                diff_result = summary.get("diff_result")
                docmdp_ok = summary.get("docmdp_ok", False)
                modification_level = getattr(diff_result, "modification_level", None)
                clean = docmdp_ok and modification_level is not None and str(modification_level).endswith("NONE")
                if clean:
                    intact = True
                    detail = "Valid - the document has not been changed since this signature was applied."
                else:
                    intact = False
                    detail = "INVALID - the document appears to have been modified since this signature was applied."
            except Exception as exc:
                intact = False
                detail = f"INVALID or unreadable signature ({exc})."

            results.append({
                "field_name": sig.field_name,
                "signer_cn": signer_cn,
                "organization": organization,
                "signed_at": signed_at,
                "intact": intact,
                "detail": detail,
            })
    return results


# --------------------------------------------------------------------------
# GUI
# --------------------------------------------------------------------------

COLOR_CHOICES = {
    "Black": (0.0, 0.0, 0.0),
    "Blue": (0.06, 0.15, 0.55),
    "Dark Red": (0.45, 0.05, 0.05),
}


def _rgb_to_hex(rgb):
    return "#%02x%02x%02x" % tuple(int(round(c * 255)) for c in rgb)


class DragState:
    __slots__ = ("target", "mode", "start_cx", "start_cy", "orig_rect")

    def __init__(self, target, mode, start_cx, start_cy, orig_rect):
        self.target = target          # "sig" or "text"
        self.mode = mode              # "move" or "resize"
        self.start_cx = start_cx      # canvas coords at press
        self.start_cy = start_cy
        self.orig_rect = orig_rect    # rect (pdf pts) at press


class PDFSignApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_TITLE} v{APP_VERSION}")
        self.geometry("1180x760")
        self.minsize(860, 560)

        if fitz is None or Image is None:
            messagebox.showerror(
                APP_TITLE,
                "Required libraries are missing (PyMuPDF / Pillow).\n"
                "This should not happen in the packaged .exe - please "
                "reinstall the application.",
            )

        self.cfg = load_config()

        # Document state
        self.doc = None
        self.pdf_path = None
        self.page_index = 0
        self.zoom = DEFAULT_ZOOM
        self.ref_page_size = (595.0, 842.0)  # A4 default until a PDF is open

        # Signature state
        self.sig_image_path = None
        self.sig_pil_image = None

        # Placement rectangles, in the coordinate space of self.ref_page_size
        self.sig_rect = None
        self.text_rect = None
        self.selected = None  # "sig" | "text" | None
        self.drag = None

        # Tk photo references (must be kept alive)
        self._page_photo = None
        self._sig_preview_photo = None

        # Options
        self.include_sig_var = tk.BooleanVar(value=True)
        self.include_text_var = tk.BooleanVar(value=True)
        self.bold_var = tk.BooleanVar(value=False)
        self.font_size_var = tk.IntVar(value=8)  # Arial 8 - a small, unobtrusive stamp by default
        self.color_var = tk.StringVar(value="Black")
        self.page_mode_var = tk.StringVar(value="current")
        self.custom_pages_var = tk.StringVar(value="")
        self.signer_name_var = tk.StringVar(value=self.cfg.get("signer_name", ""))
        self.location_var = tk.StringVar(value=self.cfg.get("default_location", ""))
        self.status_var = tk.StringVar(value="Open a PDF to begin.")
        self.page_label_var = tk.StringVar(value="No document open")

        # Internet-based location/time detection (optional; see module
        # docstring). Everything stays None/False until the user clicks
        # "Detect Location & Time (Internet)" and it succeeds.
        self.include_coords_var = tk.BooleanVar(value=False)
        self.detect_status_var = tk.StringVar(
            value="Location/date/time not yet checked against the internet - "
                  "using this computer's clock until you click Detect."
        )
        self.detected_lat = None
        self.detected_lon = None
        self.gps_accuracy_m = None       # set only when coordinates came from the browser GPS flow
        self.coords_are_precise = False  # True = browser GPS, False = IP-based estimate
        self._detected_place = None
        self.internet_dt_utc = None  # aware UTC datetime from the last successful lookup
        self._detecting = False
        self._gps_capturing = False
        self._geo_server = None
        self.location_var.trace_add("write", self._on_location_edited)

        # Free cryptographic digital signature (v2.0, optional; see the
        # "Free cryptographic digital signature" section above). Off by
        # default so v1.0-style visual-only stamping keeps working exactly
        # as before unless the user opts in.
        self.apply_crypto_sig_var = tk.BooleanVar(value=False)
        self.cert_status_var = tk.StringVar(value=self._describe_cert_status())

        self._build_menu()
        self._build_toolbar()
        self._build_body()

        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # Try to restore the last-used signature automatically (portable:
        # only works if that path still exists on this machine).
        last_sig = self.cfg.get("last_signature_path")
        if last_sig and os.path.exists(last_sig):
            self._set_signature_image(last_sig, silent=True)

    # -- UI construction ---------------------------------------------------

    def _build_menu(self):
        menubar = tk.Menu(self)

        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="Open PDF...", accelerator="Ctrl+O", command=self.open_pdf)
        filemenu.add_command(label="Load Signature Image...", command=self.load_signature)
        filemenu.add_separator()
        filemenu.add_command(label="Export Signed PDF...", accelerator="Ctrl+S", command=self.export_pdf)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=self._on_close)
        menubar.add_cascade(label="File", menu=filemenu)

        viewmenu = tk.Menu(menubar, tearoff=0)
        viewmenu.add_command(label="Fit Width", command=self.fit_width)
        viewmenu.add_command(label="Zoom In", accelerator="Ctrl++", command=self.zoom_in)
        viewmenu.add_command(label="Zoom Out", accelerator="Ctrl+-", command=self.zoom_out)
        viewmenu.add_command(label="Reset Placement", command=self.reset_placement)
        menubar.add_cascade(label="View", menu=viewmenu)

        secmenu = tk.Menu(menubar, tearoff=0)
        secmenu.add_command(label="Set Up Digital Signature (Free)...", command=self._setup_digital_signature_dialog)
        secmenu.add_command(label="Verify PDF Signature...", command=self._verify_signature_dialog)
        menubar.add_cascade(label="Security", menu=secmenu)

        helpmenu = tk.Menu(menubar, tearoff=0)
        helpmenu.add_command(label="About", command=self._show_about)
        menubar.add_cascade(label="Help", menu=helpmenu)

        self.config(menu=menubar)

        self.bind("<Control-o>", lambda e: self.open_pdf())
        self.bind("<Control-s>", lambda e: self.export_pdf())
        self.bind("<Control-plus>", lambda e: self.zoom_in())
        self.bind("<Control-minus>", lambda e: self.zoom_out())

    def _build_toolbar(self):
        bar = ttk.Frame(self, padding=(8, 6))
        bar.pack(side=tk.TOP, fill=tk.X)

        ttk.Button(bar, text="Open PDF", command=self.open_pdf).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(bar, text="Load Signature Image", command=self.load_signature).pack(side=tk.LEFT, padx=(0, 14))

        nav = ttk.Frame(bar)
        nav.pack(side=tk.LEFT, padx=(0, 14))
        ttk.Button(nav, text="< Prev", width=7, command=self.prev_page).pack(side=tk.LEFT)
        ttk.Label(nav, textvariable=self.page_label_var, width=16, anchor="center").pack(side=tk.LEFT, padx=4)
        ttk.Button(nav, text="Next >", width=7, command=self.next_page).pack(side=tk.LEFT)

        zoomf = ttk.Frame(bar)
        zoomf.pack(side=tk.LEFT, padx=(0, 14))
        ttk.Button(zoomf, text="Fit Width", command=self.fit_width).pack(side=tk.LEFT)
        ttk.Button(zoomf, text="-", width=2, command=self.zoom_out).pack(side=tk.LEFT, padx=(4, 0))
        ttk.Button(zoomf, text="+", width=2, command=self.zoom_in).pack(side=tk.LEFT, padx=(2, 0))

        ttk.Button(bar, text="Export Signed PDF", command=self.export_pdf).pack(side=tk.RIGHT)

    def _build_body(self):
        body = ttk.Frame(self)
        body.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # --- Canvas area with scrollbars ---
        canvas_frame = ttk.Frame(body)
        canvas_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(canvas_frame, bg="#77808a", highlightthickness=0)
        vbar = ttk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=self.canvas.yview)
        hbar = ttk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL, command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)

        self.canvas.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        hbar.grid(row=1, column=0, sticky="ew")
        canvas_frame.rowconfigure(0, weight=1)
        canvas_frame.columnconfigure(0, weight=1)

        self.canvas.bind("<ButtonPress-1>", self._on_press)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)
        self.canvas.bind_all("<Left>", lambda e: self._nudge(-1, 0, e))
        self.canvas.bind_all("<Right>", lambda e: self._nudge(1, 0, e))
        self.canvas.bind_all("<Up>", lambda e: self._nudge(0, -1, e))
        self.canvas.bind_all("<Down>", lambda e: self._nudge(0, 1, e))

        # --- Side panel ---
        side = ttk.Frame(body, padding=10, width=300)
        side.pack(side=tk.RIGHT, fill=tk.Y)
        side.pack_propagate(False)
        self._build_side_panel(side)

        # --- Status bar ---
        status = ttk.Frame(self, padding=(8, 3))
        status.pack(side=tk.BOTTOM, fill=tk.X)
        ttk.Label(status, textvariable=self.status_var, foreground="#333").pack(side=tk.LEFT)
        ttk.Label(
            status, text=LICENSE_TEXT, foreground="#888", font=("Helvetica", 8)
        ).pack(side=tk.RIGHT)

    def _build_side_panel(self, parent):
        ttk.Label(parent, text="Name / Place / Date / Time text", font=("", 10, "bold")).pack(anchor="w")

        namef = ttk.Frame(parent)
        namef.pack(fill=tk.X, pady=(6, 2))
        ttk.Label(namef, text="Name:").pack(side=tk.LEFT)
        name_entry = ttk.Entry(namef, textvariable=self.signer_name_var)
        name_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(6, 0))

        locf = ttk.Frame(parent)
        locf.pack(fill=tk.X, pady=(2, 2))
        ttk.Label(locf, text="Location:").pack(side=tk.LEFT)
        loc_entry = ttk.Entry(locf, textvariable=self.location_var)
        loc_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(6, 0))

        self.detect_btn = ttk.Button(
            parent, text="Detect Location & Time (Internet)", command=self.detect_via_internet
        )
        self.detect_btn.pack(fill=tk.X, pady=(4, 2))
        self.gps_btn = ttk.Button(
            parent, text="Get Exact GPS via Browser", command=self.detect_via_browser_gps
        )
        self.gps_btn.pack(fill=tk.X, pady=(0, 2))
        ttk.Checkbutton(
            parent, text="Include latitude/longitude in stamp",
            variable=self.include_coords_var, command=self.redraw_overlays,
        ).pack(anchor="w")
        ttk.Label(
            parent, textvariable=self.detect_status_var, foreground="#666",
            font=("Helvetica", 8), wraplength=270, justify="left",
        ).pack(anchor="w", pady=(2, 6))

        ttk.Button(
            parent, text="Insert / Refresh Stamp Text", command=self.refresh_stamp_text
        ).pack(fill=tk.X, pady=(0, 6))

        self.text_widget = tk.Text(parent, height=5, wrap="word", font=("Helvetica", 10))
        self.text_widget.pack(fill=tk.X)
        self.text_widget.bind("<KeyRelease>", lambda e: self.redraw_overlays())
        self.text_widget.insert(
            "1.0",
            format_stamp_text(
                self.location_var.get(), datetime.datetime.now(),
                name=self.signer_name_var.get(),
            ),
        )

        ttk.Label(parent, text="Font: Arial", foreground="#666", font=("Helvetica", 8)).pack(anchor="w", pady=(4, 0))
        opts = ttk.Frame(parent)
        opts.pack(fill=tk.X, pady=(2, 4))
        ttk.Checkbutton(opts, text="Bold", variable=self.bold_var, command=self.redraw_overlays).pack(side=tk.LEFT)
        ttk.Label(opts, text="Size:").pack(side=tk.LEFT, padx=(10, 2))
        size_spin = ttk.Spinbox(
            opts, from_=6, to=48, width=4, textvariable=self.font_size_var,
            command=self.redraw_overlays,
        )
        size_spin.pack(side=tk.LEFT)
        size_spin.bind("<KeyRelease>", lambda e: self.redraw_overlays())

        colorf = ttk.Frame(parent)
        colorf.pack(fill=tk.X, pady=(2, 10))
        ttk.Label(colorf, text="Ink color:").pack(side=tk.LEFT)
        color_combo = ttk.Combobox(
            colorf, textvariable=self.color_var, values=list(COLOR_CHOICES.keys()),
            state="readonly", width=10,
        )
        color_combo.pack(side=tk.LEFT, padx=(6, 0))
        color_combo.bind("<<ComboboxSelected>>", lambda e: self.redraw_overlays())

        ttk.Separator(parent, orient="horizontal").pack(fill=tk.X, pady=8)

        ttk.Label(parent, text="What to stamp", font=("", 10, "bold")).pack(anchor="w")
        ttk.Checkbutton(
            parent, text="Include signature image", variable=self.include_sig_var,
            command=self.redraw_overlays,
        ).pack(anchor="w", pady=(4, 0))
        ttk.Checkbutton(
            parent, text="Include Place/Date/Time text", variable=self.include_text_var,
            command=self.redraw_overlays,
        ).pack(anchor="w")

        ttk.Separator(parent, orient="horizontal").pack(fill=tk.X, pady=8)

        ttk.Label(parent, text="Digital signature (free, v2.0)", font=("", 10, "bold")).pack(anchor="w")
        ttk.Checkbutton(
            parent, text="Apply digital signature too",
            variable=self.apply_crypto_sig_var,
        ).pack(anchor="w", pady=(4, 0))
        ttk.Label(
            parent, text="(cryptographic, tamper-evident)",
            foreground="#777", font=("Helvetica", 8),
        ).pack(anchor="w", padx=(20, 0))
        ttk.Button(
            parent, text="Set Up / Manage Digital Signature...",
            command=self._setup_digital_signature_dialog,
        ).pack(fill=tk.X, pady=(4, 2))
        ttk.Label(
            parent, textvariable=self.cert_status_var, foreground="#666",
            font=("Helvetica", 8), wraplength=270, justify="left",
        ).pack(anchor="w", pady=(0, 2))

        ttk.Separator(parent, orient="horizontal").pack(fill=tk.X, pady=8)

        ttk.Label(parent, text="Pages to stamp", font=("", 10, "bold")).pack(anchor="w")
        ttk.Radiobutton(
            parent, text="Current page only", value="current", variable=self.page_mode_var
        ).pack(anchor="w", pady=(4, 0))
        ttk.Radiobutton(
            parent, text="All pages", value="all", variable=self.page_mode_var
        ).pack(anchor="w")
        custom_row = ttk.Frame(parent)
        custom_row.pack(fill=tk.X)
        ttk.Radiobutton(
            custom_row, text="Custom:", value="custom", variable=self.page_mode_var
        ).pack(side=tk.LEFT)
        ttk.Entry(custom_row, textvariable=self.custom_pages_var, width=14).pack(side=tk.LEFT, padx=(4, 0))
        ttk.Label(parent, text="e.g. 1,3,5-7", foreground="#777").pack(anchor="w", padx=(20, 0))

        ttk.Separator(parent, orient="horizontal").pack(fill=tk.X, pady=8)

        ttk.Button(parent, text="Reset Placement", command=self.reset_placement).pack(fill=tk.X)
        ttk.Label(
            parent,
            text="Tip: drag the boxes on the page to position them; "
                 "drag the small square at the bottom-right corner to resize. "
                 "Click a box then use arrow keys for pixel-precise nudging.",
            wraplength=270, foreground="#555", justify="left",
        ).pack(anchor="w", pady=(10, 0))

        ttk.Button(
            parent, text="Export Signed PDF", command=self.export_pdf
        ).pack(fill=tk.X, pady=(16, 0), ipady=6)

    def _show_about(self):
        messagebox.showinfo(
            APP_TITLE,
            f"{APP_TITLE} v{APP_VERSION}\n\n"
            "Place a signature image and a Name/Place/Date/Time stamp onto "
            "a PDF, entirely on your own computer - no account needed.\n\n"
            "Two location buttons are optional, only run when clicked, and "
            "only work if this computer currently has internet access:\n"
            "  - 'Detect Location & Time (Internet)' looks up an "
            "approximate location and a verified time from your public "
            "IP address.\n"
            "  - 'Get Exact GPS via Browser' briefly opens your web "
            "browser to ask it for the device's exact GPS coordinates, "
            "then brings the result back here.\n"
            "Without internet access, or if you don't click either "
            "button, everything works exactly as before using manual "
            "entry and this computer's own clock.\n\n"
            "New in v2.0: an optional, free cryptographic digital "
            "signature (Security menu) - a genuine, tamper-evident "
            "PAdES signature using a self-signed certificate generated "
            "on this computer, at no cost. This is on top of, not "
            "instead of, the visual stamp above.\n\n"
            "Built with Python, Tkinter, PyMuPDF and pyHanko."
            f"\n\n{LICENSE_TEXT}",
        )

    # -- Digital signature (v2.0, optional) ---------------------------------

    def _describe_cert_status(self):
        if not SIGNING_AVAILABLE:
            return "Digital signature support is not available in this build."
        path = certificate_path()
        if os.path.exists(path):
            return "A free digital signature certificate is set up on this computer."
        return "No digital signature certificate yet - click above to create one (free, one-time)."

    def _setup_digital_signature_dialog(self):
        if not SIGNING_AVAILABLE:
            messagebox.showerror(
                APP_TITLE,
                "Digital signature support is not available in this build "
                f"(missing library: {_SIGNING_IMPORT_ERROR}).",
            )
            return

        already_exists = os.path.exists(certificate_path())

        dlg = tk.Toplevel(self)
        dlg.title("Set Up Digital Signature (Free)")
        dlg.transient(self)
        dlg.grab_set()
        dlg.resizable(False, False)

        pad = ttk.Frame(dlg, padding=14)
        pad.pack(fill=tk.BOTH, expand=True)

        intro = (
            "This creates a free, self-signed certificate on this computer "
            "used to cryptographically sign your exported PDFs - proving "
            "who signed a document and detecting any change made to it "
            "afterwards. No cost, no external certificate authority, no "
            "internet connection needed.\n\n"
            "Note: because it's self-signed (not issued by a paid, "
            "publicly-trusted certificate authority), PDF viewers will "
            "show the signature as cryptographically intact, but not "
            "automatically \"trusted\" unless your institution's "
            "certificate is added to a recipient's trusted list."
        )
        if already_exists:
            intro = "A certificate already exists on this computer. Creating a new one below will replace it.\n\n" + intro
        ttk.Label(pad, text=intro, wraplength=380, justify="left").pack(anchor="w", pady=(0, 10))

        def row(label_text, show=None):
            f = ttk.Frame(pad)
            f.pack(fill=tk.X, pady=(0, 6))
            ttk.Label(f, text=label_text, width=16).pack(side=tk.LEFT)
            var = tk.StringVar()
            entry = ttk.Entry(f, textvariable=var, show=show)
            entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
            return var, entry

        name_var, name_entry = row("Name:")
        name_var.set(self.signer_name_var.get())
        org_var, _ = row("Organization:")
        org_var.set(LICENSE_TEXT.split("(")[-1].rstrip(")") if "(" in LICENSE_TEXT else "")
        pw_var, _ = row("Password:", show="*")
        pw2_var, _ = row("Confirm password:", show="*")

        ttk.Label(
            pad, text="Choose a password to protect this certificate - you'll "
                       "be asked for it each time you apply a digital signature.",
            wraplength=380, foreground="#666", font=("Helvetica", 8), justify="left",
        ).pack(anchor="w", pady=(0, 10))

        btns = ttk.Frame(pad)
        btns.pack(fill=tk.X, pady=(4, 0))

        def do_generate():
            name = name_var.get().strip()
            org = org_var.get().strip()
            pw = pw_var.get()
            pw2 = pw2_var.get()
            if not name:
                messagebox.showwarning(APP_TITLE, "Please enter a name.", parent=dlg)
                return
            if not pw:
                messagebox.showwarning(APP_TITLE, "Please choose a password.", parent=dlg)
                return
            if pw != pw2:
                messagebox.showwarning(APP_TITLE, "Passwords do not match.", parent=dlg)
                return
            try:
                generate_self_signed_certificate(name, org, pw)
            except Exception as exc:
                messagebox.showerror(APP_TITLE, f"Could not create the certificate:\n{exc}", parent=dlg)
                return
            self.cfg["cert_signer_name"] = name
            save_config(self.cfg)
            self.cert_status_var.set(self._describe_cert_status())
            self.apply_crypto_sig_var.set(True)
            messagebox.showinfo(
                APP_TITLE,
                "Digital signature certificate created. It will now be "
                "applied whenever you export a PDF with 'Also apply "
                "cryptographic digital signature' ticked.",
                parent=dlg,
            )
            dlg.destroy()

        ttk.Button(btns, text="Cancel", command=dlg.destroy).pack(side=tk.RIGHT)
        ttk.Button(btns, text="Create Certificate", command=do_generate).pack(side=tk.RIGHT, padx=(0, 8))

        name_entry.focus_set()
        dlg.wait_window()

    def _prompt_cert_password(self):
        """Modal prompt for the certificate password. Returns the password
        string, or None if the user cancelled. Never stored to disk."""
        result = {"password": None}

        dlg = tk.Toplevel(self)
        dlg.title("Digital Signature Password")
        dlg.transient(self)
        dlg.grab_set()
        dlg.resizable(False, False)

        pad = ttk.Frame(dlg, padding=14)
        pad.pack(fill=tk.BOTH, expand=True)
        ttk.Label(pad, text="Enter your digital signature certificate password:").pack(anchor="w")
        pw_var = tk.StringVar()
        entry = ttk.Entry(pad, textvariable=pw_var, show="*")
        entry.pack(fill=tk.X, pady=(6, 10))

        def ok():
            result["password"] = pw_var.get()
            dlg.destroy()

        def cancel():
            dlg.destroy()

        btns = ttk.Frame(pad)
        btns.pack(fill=tk.X)
        ttk.Button(btns, text="Cancel", command=cancel).pack(side=tk.RIGHT)
        ttk.Button(btns, text="OK", command=ok).pack(side=tk.RIGHT, padx=(0, 8))

        entry.bind("<Return>", lambda e: ok())
        entry.focus_set()
        dlg.wait_window()
        return result["password"]

    def _verify_signature_dialog(self):
        if not SIGNING_AVAILABLE:
            messagebox.showerror(
                APP_TITLE,
                "Digital signature support is not available in this build "
                f"(missing library: {_SIGNING_IMPORT_ERROR}).",
            )
            return
        path = filedialog.askopenfilename(
            title="Verify PDF Signature",
            filetypes=[("PDF files", "*.pdf")],
        )
        if not path:
            return
        try:
            results = verify_pdf_signatures(path)
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Could not read this PDF:\n{exc}")
            return

        if not results:
            messagebox.showinfo(
                APP_TITLE,
                "No digital signature found in this PDF.\n\n"
                "It may only have the visual signature image/stamp "
                "(from NSR-Esign v1.0-style stamping), which is not the "
                "same as a cryptographic digital signature.",
            )
            return

        lines = []
        for r in results:
            when = r["signed_at"].strftime("%d-%m-%Y %I:%M %p") if r["signed_at"] else "(unknown time)"
            org = f" ({r['organization']})" if r["organization"] else ""
            lines.append(
                f"Signed by: {r['signer_cn']}{org}\n"
                f"Signed at: {when}\n"
                f"Status: {r['detail']}"
            )
        messagebox.showinfo(APP_TITLE, "\n\n".join(lines))

    # -- Document handling ---------------------------------------------------

    def open_pdf(self):
        initialdir = self.cfg.get("last_open_dir") or os.path.expanduser("~")
        path = filedialog.askopenfilename(
            title="Open PDF",
            initialdir=initialdir,
            filetypes=[("PDF files", "*.pdf")],
        )
        if not path:
            return
        try:
            doc = fitz.open(path)
            if doc.page_count == 0:
                raise ValueError("This PDF has no pages.")
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Could not open this PDF:\n{exc}")
            return

        if self.doc is not None:
            self.doc.close()

        self.doc = doc
        self.pdf_path = path
        self.page_index = 0
        self.cfg["last_open_dir"] = os.path.dirname(path)
        save_config(self.cfg)

        page = self.doc[0]
        self.ref_page_size = (page.rect.width, page.rect.height)
        self.reset_placement(render=False)
        self.fit_width()
        self.status_var.set(f"Opened {os.path.basename(path)} ({self.doc.page_count} page(s)).")

    def load_signature(self):
        initialdir = self.cfg.get("last_signature_dir") or os.path.expanduser("~")
        path = filedialog.askopenfilename(
            title="Choose signature image",
            initialdir=initialdir,
            filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp *.gif"), ("All files", "*.*")],
        )
        if not path:
            return
        self._set_signature_image(path)
        self.cfg["last_signature_dir"] = os.path.dirname(path)
        self.cfg["last_signature_path"] = path
        save_config(self.cfg)

    def _set_signature_image(self, path, silent=False):
        try:
            img = Image.open(path)
            img.load()
        except Exception as exc:
            if not silent:
                messagebox.showerror(APP_TITLE, f"Could not open this image:\n{exc}")
            return
        self.sig_image_path = path
        self.sig_pil_image = img.convert("RGBA")
        if self.doc is not None:
            self.redraw_overlays()
        self.status_var.set(f"Signature loaded: {os.path.basename(path)}")

    # -- Placement defaults ---------------------------------------------------

    def reset_placement(self, render=True):
        w, h = self.ref_page_size
        margin = 40.0
        # Kept compact to match the small default stamp text (Arial 8).
        sig_w, sig_h = min(130.0, w * 0.28), 45.0
        sx1, sy1 = w - margin, h - margin
        sx0, sy0 = sx1 - sig_w, sy1 - sig_h
        self.sig_rect = (sx0, sy0, sx1, sy1)

        # Sized with headroom for up to 5 wrapped lines (Name / Place /
        # Lat-Long / Date / Time) at the default 8pt font - apply_stamp_to_pdf
        # also auto-shrinks the font as a safety net if a user-resized box
        # is still too small.
        text_w, text_h = min(190.0, w * 0.34), 65.0
        tx1 = max(sx0 - 16.0, text_w)
        tx0 = max(tx1 - text_w, 0.0)
        ty1 = sy1
        ty0 = max(ty1 - text_h, 0.0)
        self.text_rect = (tx0, ty0, tx0 + text_w, ty1)

        if render and self.doc is not None:
            self.render_page()

    # -- Rendering ---------------------------------------------------------

    def render_page(self):
        if self.doc is None:
            return
        page = self.doc[self.page_index]
        w, h = page.rect.width, page.rect.height

        # Rescale saved placement rects if the page size changed since they
        # were last positioned (e.g. navigating to a differently-sized page).
        if (w, h) != self.ref_page_size:
            self.sig_rect = scale_rect_between_pages(self.sig_rect, *self.ref_page_size, w, h)
            self.text_rect = scale_rect_between_pages(self.text_rect, *self.ref_page_size, w, h)
            self.ref_page_size = (w, h)

        zoom = self.zoom
        px_w, px_h = w * zoom, h * zoom
        if px_w > MAX_CANVAS_DIM or px_h > MAX_CANVAS_DIM:
            zoom = min(MAX_CANVAS_DIM / w, MAX_CANVAS_DIM / h)
            self.zoom = zoom

        mat = fitz.Matrix(self.zoom, self.zoom)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        mode = "RGB"
        pil_img = Image.frombytes(mode, (pix.width, pix.height), pix.samples)
        self._page_photo = ImageTk.PhotoImage(pil_img)

        self.canvas.delete("all")
        self.canvas.create_image(0, 0, anchor="nw", image=self._page_photo, tags="page")
        self.canvas.config(scrollregion=(0, 0, pix.width, pix.height))

        self.page_label_var.set(f"Page {self.page_index + 1} of {self.doc.page_count}")
        self.redraw_overlays()

    def redraw_overlays(self):
        self.canvas.delete("sigbox", "sighandle", "sigpreview")
        self.canvas.delete("textbox", "texthandle", "textpreview")
        if self.doc is None:
            return

        color_rgb = COLOR_CHOICES.get(self.color_var.get(), (0, 0, 0))
        color_hex = _rgb_to_hex(color_rgb)

        # Signature box
        if self.sig_rect is not None:
            x0, y0, x1, y1 = (v * self.zoom for v in self.sig_rect)
            outline_w = 3 if self.selected == "sig" else 2
            dash = () if self.selected == "sig" else (4, 3)
            self.canvas.create_rectangle(
                x0, y0, x1, y1, outline="#1a73e8", width=outline_w, dash=dash, tags="sigbox",
            )
            if self.sig_pil_image is not None and self.include_sig_var.get():
                box_w, box_h = max(int(x1 - x0), 1), max(int(y1 - y0), 1)
                thumb = self._fit_image(self.sig_pil_image, box_w, box_h)
                self._sig_preview_photo = ImageTk.PhotoImage(thumb)
                cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
                self.canvas.create_image(cx, cy, image=self._sig_preview_photo, tags=("sigbox", "sigpreview"))
            else:
                self.canvas.create_text(
                    (x0 + x1) / 2, (y0 + y1) / 2,
                    text="Signature\n(load an image)", fill="#1a73e8",
                    font=("Helvetica", 9), tags="sigbox", justify="center",
                )
            self._draw_handle(x1, y1, "sighandle")

        # Text box
        if self.text_rect is not None:
            x0, y0, x1, y1 = (v * self.zoom for v in self.text_rect)
            outline_w = 3 if self.selected == "text" else 2
            dash = () if self.selected == "text" else (4, 3)
            self.canvas.create_rectangle(
                x0, y0, x1, y1, outline="#d23f31", width=outline_w, dash=dash, tags="textbox",
            )
            if self.include_text_var.get():
                content = self.text_widget.get("1.0", "end-1c") if hasattr(self, "text_widget") else ""
                px_size = max(6, int(self.font_size_var.get() * self.zoom))
                weight = "bold" if self.bold_var.get() else "normal"
                self.canvas.create_text(
                    x0 + 4, y0 + 4, anchor="nw", text=content,
                    font=("Arial", px_size, weight), fill=color_hex,
                    width=max(int(x1 - x0) - 8, 10), tags="textbox",
                )
            self._draw_handle(x1, y1, "texthandle")

    @staticmethod
    def _fit_image(pil_img, box_w, box_h):
        img_ratio = pil_img.width / max(pil_img.height, 1)
        box_ratio = box_w / max(box_h, 1)
        if img_ratio > box_ratio:
            new_w = box_w
            new_h = max(int(box_w / img_ratio), 1)
        else:
            new_h = box_h
            new_w = max(int(box_h * img_ratio), 1)
        return pil_img.resize((max(new_w, 1), max(new_h, 1)))

    def _draw_handle(self, x1, y1, tag):
        h = HANDLE_PX
        self.canvas.create_rectangle(
            x1 - h, y1 - h, x1, y1, fill="#ffffff", outline="#333333", tags=tag,
        )

    # -- Mouse interaction ---------------------------------------------------

    def _hit_test(self, cx, cy):
        """Returns (target, mode) or (None, None)."""
        for target, rect in (("sig", self.sig_rect), ("text", self.text_rect)):
            if rect is None:
                continue
            x0, y0, x1, y1 = (v * self.zoom for v in rect)
            hx0, hy0 = x1 - HANDLE_PX, y1 - HANDLE_PX
            if hx0 <= cx <= x1 + HANDLE_PX and hy0 <= cy <= y1 + HANDLE_PX:
                return target, "resize"
        # Check box bodies on top (sig drawn after text visually, but test
        # sig first so it's easier to grab when boxes overlap).
        for target, rect in (("sig", self.sig_rect), ("text", self.text_rect)):
            if rect is None:
                continue
            x0, y0, x1, y1 = (v * self.zoom for v in rect)
            if x0 <= cx <= x1 and y0 <= cy <= y1:
                return target, "move"
        return None, None

    def _on_press(self, event):
        if self.doc is None:
            return
        cx, cy = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        target, mode = self._hit_test(cx, cy)
        self.selected = target
        if target is None:
            self.redraw_overlays()
            return
        orig_rect = self.sig_rect if target == "sig" else self.text_rect
        self.drag = DragState(target, mode, cx, cy, orig_rect)
        self.redraw_overlays()

    def _on_drag(self, event):
        if self.drag is None or self.doc is None:
            return
        cx, cy = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        dx_pt = (cx - self.drag.start_cx) / self.zoom
        dy_pt = (cy - self.drag.start_cy) / self.zoom
        x0, y0, x1, y1 = self.drag.orig_rect
        page_w, page_h = self.ref_page_size

        if self.drag.mode == "move":
            new_rect = clamp_rect_to_page((x0 + dx_pt, y0 + dy_pt, x1 + dx_pt, y1 + dy_pt), page_w, page_h)
        else:  # resize (bottom-right handle)
            new_x1 = min(max(x1 + dx_pt, x0 + MIN_BOX_PT), page_w)
            new_y1 = min(max(y1 + dy_pt, y0 + MIN_BOX_PT), page_h)
            new_rect = (x0, y0, new_x1, new_y1)

        if self.drag.target == "sig":
            self.sig_rect = new_rect
        else:
            self.text_rect = new_rect
        self.redraw_overlays()

    def _on_release(self, event):
        self.drag = None

    def _nudge(self, dx, dy, event):
        if self.selected is None or self.doc is None:
            return
        # Avoid hijacking arrow-key navigation while typing in a text field.
        w = self.focus_get()
        if isinstance(w, (tk.Text, tk.Entry, ttk.Entry, ttk.Spinbox)):
            return
        step = 5.0 if (event.state & 0x0001) else 1.0  # Shift = bigger step
        page_w, page_h = self.ref_page_size
        rect = self.sig_rect if self.selected == "sig" else self.text_rect
        if rect is None:
            return
        x0, y0, x1, y1 = rect
        new_rect = clamp_rect_to_page(
            (x0 + dx * step, y0 + dy * step, x1 + dx * step, y1 + dy * step), page_w, page_h
        )
        if self.selected == "sig":
            self.sig_rect = new_rect
        else:
            self.text_rect = new_rect
        self.redraw_overlays()

    # -- Text stamp ---------------------------------------------------------

    def _current_datetime(self):
        """The datetime to stamp with: the last internet-verified UTC time
        (converted to this computer's local wall-clock offset) if a lookup
        has succeeded, otherwise this computer's own clock."""
        if self.internet_dt_utc is not None:
            return self.internet_dt_utc.astimezone()
        return datetime.datetime.now()

    def refresh_stamp_text(self):
        self.cfg["default_location"] = self.location_var.get()
        self.cfg["signer_name"] = self.signer_name_var.get()
        save_config(self.cfg)
        dt = self._current_datetime()
        text = format_stamp_text(
            self.location_var.get(), dt,
            lat=self.detected_lat, lon=self.detected_lon,
            include_coords=self.include_coords_var.get(),
            verified=self.internet_dt_utc is not None,
            precise=self.coords_are_precise,
            accuracy_m=self.gps_accuracy_m,
            name=self.signer_name_var.get(),
        )
        self.text_widget.delete("1.0", "end")
        self.text_widget.insert("1.0", text)
        self.redraw_overlays()

    def _on_location_edited(self, *_args):
        """If the user hand-edits the Location field after a successful
        internet detection, the previously-detected coordinates no longer
        necessarily match what's typed - clear them so the stamp can't
        show a place name and lat/long that disagree. The internet-verified
        time stays valid regardless of the place name."""
        if self._detecting or self._gps_capturing:
            return
        current = self.location_var.get()
        if self._detected_place is not None and current != self._detected_place:
            self.detected_lat = None
            self.detected_lon = None
            self.gps_accuracy_m = None
            self.coords_are_precise = False
            self._detected_place = None

    def detect_via_internet(self):
        if self._detecting:
            return
        self._detecting = True
        self.detect_btn.config(state="disabled")
        self.detect_status_var.set("Checking internet connection and detecting location...")

        def worker():
            try:
                place, lat, lon, dt_utc = fetch_internet_location_and_time()
            except Exception as exc:  # noqa: BLE001 - report any failure, don't crash the thread
                self.after(0, lambda: self._on_detect_failure(exc))
                return
            self.after(0, lambda: self._on_detect_success(place, lat, lon, dt_utc))

        threading.Thread(target=worker, daemon=True).start()

    def _on_detect_success(self, place, lat, lon, dt_utc):
        self._detecting = False
        self.detect_btn.config(state="normal")
        self.internet_dt_utc = dt_utc
        self._detected_place = place or None
        if place:
            self.location_var.set(place)  # _detected_place is already set, so the
                                           # trace above won't clear the coordinates

        kept_precise = False
        if self.coords_are_precise and self.detected_lat is not None:
            # Don't downgrade an already-captured exact GPS fix with a
            # coarser IP-based estimate - just refresh place name/time.
            kept_precise = True
        else:
            self.detected_lat, self.detected_lon = lat, lon
            self.gps_accuracy_m = None
            self.coords_are_precise = False

        local_dt = dt_utc.astimezone()
        if self.detected_lat is not None and self.detected_lon is not None:
            coord_txt = f"  (Lat {self.detected_lat:.4f}, Long {self.detected_lon:.4f})"
            if kept_precise:
                coord_txt += " - kept your earlier exact GPS fix"
        else:
            coord_txt = ""
        self.detect_status_var.set(
            f"Detected: {place or 'location unavailable'}{coord_txt}\n"
            f"Internet time: {local_dt.strftime('%d-%m-%Y %I:%M %p')}"
        )
        self.refresh_stamp_text()

    def _on_detect_failure(self, exc):
        self._detecting = False
        self.detect_btn.config(state="normal")
        self.detect_status_var.set(
            "No internet connection right now - using the location you type "
            "in by hand and this computer's system clock instead."
        )
        messagebox.showwarning(
            APP_TITLE,
            "Could not detect your location and time over the internet.\n\n"
            f"{exc}\n\n"
            "You can still type the location in by hand - the date/time "
            "will use this computer's own clock.",
        )

    # -- Exact GPS via the browser -------------------------------------------

    def detect_via_browser_gps(self):
        if self._gps_capturing:
            return
        self._gps_capturing = True
        self.gps_btn.config(state="disabled")
        self.detect_status_var.set(
            "Opening your browser to request an exact GPS location - please "
            "allow the location permission prompt there, then come back here."
        )

        try:
            server, result = start_geo_capture_server()
        except OSError as exc:
            self._gps_capturing = False
            self.gps_btn.config(state="normal")
            messagebox.showerror(
                APP_TITLE,
                f"Could not start the local helper server for browser GPS:\n{exc}",
            )
            return

        self._geo_server = server
        port = server.server_address[1]
        url = f"http://127.0.0.1:{port}/"

        threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.2}, daemon=True).start()

        opened = webbrowser.open(url)
        if not opened:
            server.shutdown()
            self._geo_server = None
            self._gps_capturing = False
            self.gps_btn.config(state="normal")
            self.detect_status_var.set("Could not open a web browser automatically.")
            return

        def waiter():
            got_response = result.event.wait(timeout=120)
            try:
                server.shutdown()
            except Exception:
                pass
            if got_response and result.lat is not None and result.lon is not None:
                self.after(0, lambda: self._on_gps_success(result.lat, result.lon, result.accuracy))
            elif got_response and result.error:
                self.after(0, lambda: self._on_gps_failure(result.error))
            else:
                self.after(0, lambda: self._on_gps_failure(
                    "Timed out waiting for a response from the browser."
                ))

        threading.Thread(target=waiter, daemon=True).start()

    def _on_gps_success(self, lat, lon, accuracy):
        self._gps_capturing = False
        self.gps_btn.config(state="normal")
        self._geo_server = None
        self.detected_lat, self.detected_lon = lat, lon
        self.gps_accuracy_m = accuracy
        self.coords_are_precise = True
        self.include_coords_var.set(True)

        acc_txt = f" (±{accuracy:.0f} m)" if accuracy is not None else ""
        self.detect_status_var.set(
            f"Exact GPS captured via browser: {lat:.6f}, {lon:.6f}{acc_txt}\n"
            "Looking up a place name for these coordinates..."
        )
        self.refresh_stamp_text()
        self._start_reverse_geocode(lat, lon)

    def _on_gps_failure(self, message):
        self._gps_capturing = False
        self.gps_btn.config(state="normal")
        self._geo_server = None
        self.detect_status_var.set(f"Could not get an exact GPS location: {message}")
        messagebox.showwarning(
            APP_TITLE,
            f"Could not get a precise location from your browser.\n\n{message}\n\n"
            "You can still use 'Detect Location & Time (Internet)' for an "
            "approximate location, or type it in by hand.",
        )

    def _start_reverse_geocode(self, lat, lon):
        def worker():
            place = reverse_geocode(lat, lon)
            if place:
                self.after(0, lambda: self._apply_reverse_geocoded_place(place, lat, lon))
            else:
                self.after(0, lambda: self.detect_status_var.set(
                    self.detect_status_var.get().replace(
                        "Looking up a place name for these coordinates...",
                        "(could not determine a place name for these coordinates - "
                        "type one in by hand if you'd like)",
                    )
                ))

        threading.Thread(target=worker, daemon=True).start()

    def _apply_reverse_geocoded_place(self, place, lat, lon):
        # Only apply if these coordinates are still the ones in use (the
        # user may have started a new detection in the meantime).
        if self.detected_lat != lat or self.detected_lon != lon:
            return
        self._detected_place = place
        self.location_var.set(place)  # _detected_place already matches, trace won't clear coords
        self.detect_status_var.set(
            self.detect_status_var.get().replace(
                "Looking up a place name for these coordinates...",
                f"Place (via reverse geocoding): {place}",
            )
        )
        self.refresh_stamp_text()

    # -- Navigation / zoom ---------------------------------------------------

    def prev_page(self):
        if self.doc is None or self.page_index <= 0:
            return
        self.page_index -= 1
        self.render_page()

    def next_page(self):
        if self.doc is None or self.page_index >= self.doc.page_count - 1:
            return
        self.page_index += 1
        self.render_page()

    def zoom_in(self):
        if self.doc is None:
            return
        self.zoom = min(self.zoom * 1.15, 5.0)
        self.render_page()

    def zoom_out(self):
        if self.doc is None:
            return
        self.zoom = max(self.zoom * 0.87, 0.2)
        self.render_page()

    def fit_width(self):
        if self.doc is None:
            return
        self.canvas.update_idletasks()
        visible_w = max(self.canvas.winfo_width() - 24, 200)
        page_w = self.ref_page_size[0]
        self.zoom = max(min(visible_w / page_w, 5.0), 0.2)
        self.render_page()

    # -- Export ---------------------------------------------------------

    def get_target_pages(self):
        mode = self.page_mode_var.get()
        if mode == "current":
            return [self.page_index]
        if mode == "all":
            return list(range(self.doc.page_count))
        return parse_page_list(self.custom_pages_var.get(), self.doc.page_count)

    def export_pdf(self):
        if self.doc is None:
            messagebox.showwarning(APP_TITLE, "Open a PDF first.")
            return
        include_sig = self.include_sig_var.get()
        include_text = self.include_text_var.get()
        if not include_sig and not include_text:
            messagebox.showwarning(APP_TITLE, "Nothing to stamp - enable the signature and/or the text.")
            return
        if include_sig and not self.sig_image_path:
            messagebox.showwarning(APP_TITLE, "Load a signature image first, or untick 'Include signature image'.")
            return
        text_content = self.text_widget.get("1.0", "end-1c").strip()
        if include_text and not text_content:
            messagebox.showwarning(APP_TITLE, "The Place/Date/Time text box is empty.")
            return

        try:
            target_pages = self.get_target_pages()
        except ValueError as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        ref_w, ref_h = self.ref_page_size
        sig_rect_by_page = {}
        text_rect_by_page = {}
        for idx in target_pages:
            page = self.doc[idx]
            pw, ph = page.rect.width, page.rect.height
            if include_sig and self.sig_rect is not None:
                sig_rect_by_page[idx] = scale_rect_between_pages(self.sig_rect, ref_w, ref_h, pw, ph)
            if include_text and self.text_rect is not None:
                text_rect_by_page[idx] = scale_rect_between_pages(self.text_rect, ref_w, ref_h, pw, ph)

        base, _ext = os.path.splitext(os.path.basename(self.pdf_path))
        suggested = f"{base}_signed.pdf"
        initialdir = self.cfg.get("last_save_dir") or os.path.dirname(self.pdf_path)
        out_path = filedialog.asksaveasfilename(
            title="Export Signed PDF",
            initialdir=initialdir,
            initialfile=suggested,
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
        )
        if not out_path:
            return

        color_rgb = COLOR_CHOICES.get(self.color_var.get(), (0, 0, 0))
        try:
            used_fontsizes = apply_stamp_to_pdf(
                self.pdf_path,
                out_path,
                self.sig_image_path,
                sig_rect_by_page,
                text_rect_by_page,
                text_content,
                font_size=self.font_size_var.get(),
                bold=self.bold_var.get(),
                text_color=color_rgb,
                include_signature=include_sig,
                include_text=include_text,
            )
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Could not save the signed PDF:\n{exc}")
            return

        self.cfg["last_save_dir"] = os.path.dirname(out_path)
        save_config(self.cfg)
        self.status_var.set(f"Saved: {out_path}")

        sig_warning = ""
        if self.apply_crypto_sig_var.get():
            sig_warning = self._apply_crypto_signature_to_export(out_path)

        # apply_stamp_to_pdf auto-shrinks the text to make it fit its box,
        # but if the box is so small even the minimum size didn't fit, that
        # page is missing from used_fontsizes - warn plainly rather than
        # letting the text silently vanish from the exported PDF unnoticed.
        warning = ""
        if include_text and text_rect_by_page:
            failed_pages = [idx for idx in text_rect_by_page if idx not in used_fontsizes]
            shrunk_pages = [
                idx for idx, sz in used_fontsizes.items() if sz < self.font_size_var.get()
            ]
            if failed_pages:
                nums = ", ".join(str(i + 1) for i in sorted(failed_pages))
                warning += (
                    f"\n\nWarning: the Place/Date/Time text box is too small to fit "
                    f"the text on page(s) {nums}, even at the smallest font size - "
                    "it was left out there. Please make the text box bigger and "
                    "export again."
                )
            elif shrunk_pages:
                warning += (
                    "\n\nNote: the text was automatically shrunk to fit the text "
                    "box on one or more pages. Make the box bigger if you'd "
                    "prefer the text at its original size."
                )

        messagebox.showinfo(
            APP_TITLE,
            f"Signed PDF saved to:\n{out_path}\n\nStamped {len(target_pages)} page(s)."
            + warning + sig_warning,
        )

    def _apply_crypto_signature_to_export(self, out_path):
        """Applies the free cryptographic digital signature on top of an
        already-exported (visually stamped) PDF at out_path, in place.
        Returns a message suffix to append to the export success dialog -
        empty on success, or an explanation if it could not be applied (the
        visual stamp above is still saved either way)."""
        if not SIGNING_AVAILABLE:
            return (
                "\n\nNote: 'Also apply cryptographic digital signature' was "
                "ticked, but digital signature support is not available in "
                f"this build (missing library: {_SIGNING_IMPORT_ERROR}). "
                "The visual stamp above was still saved."
            )
        cert_path = certificate_path()
        if not os.path.exists(cert_path):
            return (
                "\n\nNote: 'Also apply cryptographic digital signature' was "
                "ticked, but no certificate has been set up yet (Security "
                "menu -> Set Up Digital Signature). The visual stamp above "
                "was still saved without a digital signature."
            )
        password = self._prompt_cert_password()
        if password is None:
            return (
                "\n\nNote: digital signature was skipped (no password "
                "entered). The visual stamp above was still saved."
            )
        tmp_path = out_path + ".nsr_esign_signing_tmp"
        try:
            sign_pdf_cryptographically(
                out_path, tmp_path, cert_path, password,
                signer_name=self.signer_name_var.get().strip() or self.cfg.get("cert_signer_name", ""),
                reason="Signed with NSR-Esign",
                location=self.location_var.get().strip(),
            )
            os.replace(tmp_path, out_path)
            return "\n\nA free cryptographic digital signature was applied (tamper-evident)."
        except Exception as exc:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
            return (
                f"\n\nWarning: could not apply the digital signature ({exc}). "
                "The visual stamp above was still saved without it."
            )

    # -- Lifecycle ---------------------------------------------------------

    def _on_close(self):
        save_config(self.cfg)
        if self._geo_server is not None:
            try:
                self._geo_server.shutdown()
            except Exception:
                pass
        if self.doc is not None:
            self.doc.close()
        self.destroy()


def main():
    if fitz is None:
        print("ERROR: PyMuPDF is not installed. Run: pip install pymupdf")
        sys.exit(1)
    if Image is None:
        print("ERROR: Pillow is not installed. Run: pip install pillow")
        sys.exit(1)
    app = PDFSignApp()
    app.mainloop()


if __name__ == "__main__":
    main()
